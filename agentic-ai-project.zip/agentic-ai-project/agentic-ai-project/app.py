import streamlit as st
from agents.planner import planner_agent
from agents.task_generator import task_generator
from agents.memory import save_tasks, load_tasks
from agents.executor import execute_tasks

st.title("🤖 Multi-Agent AI Task Assistant")

user_input = st.text_input("Enter your goal:")

if st.button("Generate Plan"):
    if user_input:
        st.write("### 🧠 Planner Agent Output")
        plan = planner_agent(user_input)
        st.write(plan)

        st.write("### 📝 Task Generator Output")
        tasks = task_generator(plan)
        st.write(tasks)

        save_tasks(tasks)

        st.write("### ⚙️ Execution Output")
        result = execute_tasks(tasks)
        st.write(result)

if st.button("View Saved Tasks"):
    tasks = load_tasks()
    st.write(tasks)