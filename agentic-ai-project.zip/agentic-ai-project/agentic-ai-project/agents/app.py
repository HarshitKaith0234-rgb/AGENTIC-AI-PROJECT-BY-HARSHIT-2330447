import streamlit as st

st.title("🤖 Multi-Agent AI Task Assistant")

user_input = st.text_input("Enter your goal:")

if st.button("Generate Plan"):
    if user_input:
        st.write("You entered:", user_input)