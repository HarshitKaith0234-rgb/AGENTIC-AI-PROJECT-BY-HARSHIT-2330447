def execute_tasks(tasks):
    return f"Tasks ready for execution:\n\n{tasks}"