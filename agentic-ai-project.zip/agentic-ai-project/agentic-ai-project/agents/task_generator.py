def task_generator(goal):
    return f"""
    📝 Task Breakdown:
    - Read theory
    - Solve practice questions
    - Revise notes
    - Take mock tests
    """