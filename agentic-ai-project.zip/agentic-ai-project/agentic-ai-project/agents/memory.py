import json
import os

FILE_PATH = "data/tasks.json"

def save_tasks(tasks):
    if not os.path.exists("data"):
        os.makedirs("data")

    with open(FILE_PATH, "w") as f:
        json.dump({"tasks": tasks}, f, indent=4)

def load_tasks():
    if not os.path.exists(FILE_PATH):
        return []

    with open(FILE_PATH, "r") as f:
        data = json.load(f)
        return data.get("tasks", [])