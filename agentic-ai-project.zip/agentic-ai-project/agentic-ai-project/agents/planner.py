def planner_agent(user_input):
    return f"""
    🧠 Goal Analysis:
    Your goal is: {user_input}

    📅 Study Plan:
    Day 1: Understand basic concepts
    Day 2: Practice problems
    Day 3: Revise important topics
    Day 4: Mock test
    Day 5: Final revision
    """